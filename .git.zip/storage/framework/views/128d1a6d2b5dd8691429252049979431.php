

<?php $__env->startSection('title', $book->title . ' — TurnPage'); ?>

<?php $__env->startSection('styles'); ?>
<style>
    .book-cover-large {
        height: 380px;
        background: linear-gradient(135deg, #e8e0d5, #d4c9bb);
        border-radius: 12px;
        display: flex;
        align-items: center;
        justify-content: center;
        font-size: 6rem;
        box-shadow: 0 4px 20px rgba(0,0,0,0.1);
    }
    .book-title { font-family: 'Merriweather', serif; font-size: 1.8rem; font-weight: 700; }
    .book-author { color: #666; font-size: 1rem; }
    .book-price { color: #c0392b; font-weight: 700; font-size: 1.8rem; }
    .star-rating { color: #e8a045; font-size: 1.1rem; }
    .meta-badge { background: #f0f0f0; border-radius: 6px; padding: 4px 12px; font-size: 0.85rem; color: #555; display: inline-block; margin-right: 8px; margin-bottom: 8px; }
    .btn-cart { background: #c0392b; color: #fff; border: none; padding: 12px 32px; border-radius: 8px; font-size: 1rem; }
    .btn-cart:hover { background: #a93226; color: #fff; }
    .btn-wishlist { border: 2px solid #e8a045; color: #e8a045; background: #fff; padding: 12px 24px; border-radius: 8px; font-size: 1rem; }
    .btn-wishlist:hover { background: #e8a045; color: #fff; }
    .review-card { background: #fff; border-radius: 10px; padding: 20px; margin-bottom: 16px; box-shadow: 0 2px 8px rgba(0,0,0,0.06); }
    .review-form { background: #fff; border-radius: 10px; padding: 24px; box-shadow: 0 2px 8px rgba(0,0,0,0.06); margin-bottom: 24px; }
    .section-divider { border: none; border-top: 2px solid #efe8df; margin: 40px 0; }
</style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="container mt-4 pb-5">

    <a href="<?php echo e(route('books.index')); ?>" class="text-muted text-decoration-none mb-3 d-inline-block">← Back to all books</a>

    <div class="row g-5 mt-1 reveal-on-scroll">
        <!-- Book Cover -->
        <div class="col-md-4">
            <div class="rounded-4 shadow-sm position-relative overflow-hidden" style="height: 380px; width: 100%; background: linear-gradient(135deg, #e8e0d5, #d4c9bb);">
                <div class="d-flex align-items-center justify-content-center h-100 w-100" style="font-size: 5rem; color: #6b7280; position: absolute; inset: 0;">
                    📖
                </div>
                <?php if($book->has_cover): ?>
                    <img src="<?php echo e($book->cover_url); ?>" alt="<?php echo e($book->title); ?>" class="img-fluid" style="height: 100%; width: 100%; object-fit: cover; position: absolute; inset: 0;" onerror="this.onerror=null;this.style.display='none'">
                <?php endif; ?>
            </div>
        </div>

        <!-- Book Details -->
        <div class="col-md-8">
            <h1 class="book-title mb-2"><?php echo e($book->title); ?></h1>
            <p class="book-author mb-3">by <strong><?php echo e($book->author->author_name ?? 'Unknown'); ?></strong></p>

            <p class="mb-3">
                <span class="star-rating"><?php echo e(str_repeat('★', (int)$book->star_rating)); ?><?php echo e(str_repeat('☆', 5 - (int)$book->star_rating)); ?></span>
                <span class="text-muted ms-1"><?php echo e($book->star_rating); ?> (<?php echo e($book->review_count); ?> reviews)</span>
            </p>

            <p class="book-price mb-3">Tk. <?php echo e(number_format($book->price, 2)); ?></p>

            <div class="mb-4">
                <span class="meta-badge">📚 <?php echo e($book->page_count); ?> pages</span>
                <span class="meta-badge">🌐 <?php echo e($book->language); ?></span>
                <span class="meta-badge">🏢 <?php echo e($book->publisher->publisher_name ?? 'Unknown'); ?></span>
                <?php if($book->stock_quantity > 0): ?>
                    <span class="meta-badge" style="background:#d4edda;color:#155724;">✅ In Stock (<?php echo e($book->stock_quantity); ?>)</span>
                <?php else: ?>
                    <span class="meta-badge" style="background:#f8d7da;color:#721c24;">❌ Out of Stock</span>
                <?php endif; ?>
            </div>

            <?php if($book->isbn): ?>
            <p class="text-muted small mb-4">ISBN: <?php echo e($book->isbn); ?></p>
            <?php endif; ?>

            <div class="d-flex gap-3 flex-wrap">
                <?php if($book->stock_quantity > 0): ?>
                <form action="<?php echo e(route('cart.add', $book->book_id)); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                    <button type="submit" class="btn-cart">🛒 Add to Cart</button>
                </form>
                <?php endif; ?>

                <form action="<?php echo e(route('wishlist.add', $book->book_id)); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                    <button type="submit" class="btn-wishlist">❤️ Wishlist</button>
                </form>
            </div>
        </div>
    </div>

    <hr class="section-divider">

    <!-- Related Products Section -->
    <h3 class="mb-4" style="font-family:'Merriweather',serif;">You Might Also Like</h3>
    
    <?php if($relatedBooks && $relatedBooks->count() > 0): ?>
    <div class="row g-4 mb-5">
        <?php $__currentLoopData = $relatedBooks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $relBook): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="col-md-3">
            <div class="book-card" style="background: #fff; border-radius: 10px; box-shadow: 0 2px 12px rgba(0,0,0,0.07); transition: transform 0.2s; height: 100%;">
                <div class="book-cover" style="height: 200px; overflow: hidden; border-radius: 10px 10px 0 0; position: relative; background: linear-gradient(135deg, #e5e7eb 0%, #d1d5db 100%);">
                    <div class="d-flex align-items-center justify-content-center h-100 w-100" style="font-size: 3rem; color: #6b7280; position: absolute; inset: 0;">
                        📖
                    </div>
                    <?php if($relBook->has_cover ?? false): ?>
                        <img src="<?php echo e($relBook->cover_url); ?>" alt="<?php echo e($relBook->title); ?>" class="img-fluid h-100 w-100" style="object-fit: cover; position: absolute; inset: 0;" onerror="this.style.display='none'">
                    <?php endif; ?>
                </div>
                <div class="p-3">
                    <p class="book-title mb-1"><?php echo e($relBook->title); ?></p>
                    <p class="book-author mb-2" style="color: #888; font-size: 0.82rem;"><?php echo e($relBook->author->author_name ?? 'Unknown'); ?></p>
                    <p class="star-rating mb-2" style="color: #e8a045; font-size: 0.85rem;">★ <?php echo e($relBook->star_rating); ?>

                        <small class="text-muted">(<?php echo e($relBook->review_count); ?>)</small>
                    </p>
                    <div class="d-flex justify-content-between align-items-center">
                        <span class="book-price" style="color: #c0392b; font-weight: 700;">Tk. <?php echo e(number_format($relBook->price, 0)); ?></span>
                        <a href="<?php echo e(route('books.show', $relBook->book_id)); ?>" class="btn btn-sm btn-outline-dark">View</a>
                    </div>
                </div>
            </div>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
    <?php else: ?>
    <p class="text-muted mb-5">No related books available.</p>
    <?php endif; ?>

    <hr class="section-divider">

    <!-- Review Section -->
    <h3 class="mb-4" style="font-family:'Merriweather',serif;">Customer Reviews</h3>

    <!-- Write Review Form -->
    <?php if(session('user_id')): ?>
    <div class="review-form reveal-on-scroll">
        <h6 class="mb-3">Write a Review</h6>
        <form action="<?php echo e(route('review.store', $book->book_id)); ?>" method="POST">
            <?php echo csrf_field(); ?>
            <div class="row g-3">
                <div class="col-md-3">
                    <label class="form-label small">Rating</label>
                    <select name="rating" class="form-select" required>
                        <option value="5">★★★★★ Excellent</option>
                        <option value="4">★★★★☆ Good</option>
                        <option value="3">★★★☆☆ Average</option>
                        <option value="2">★★☆☆☆ Poor</option>
                        <option value="1">★☆☆☆☆ Terrible</option>
                    </select>
                </div>
                <div class="col-md-9">
                    <label class="form-label small">Your Review</label>
                    <textarea name="review_text" class="form-control" rows="2" placeholder="Share your thoughts..."></textarea>
                </div>
            </div>
            <button type="submit" class="btn btn-dark mt-3">Submit Review</button>
        </form>
    </div>
    <?php else: ?>
    <div class="alert alert-light border mb-4">
        <a href="<?php echo e(route('login')); ?>">Login</a> to write a review.
    </div>
    <?php endif; ?>

    <!-- Reviews List -->
    <?php $__empty_1 = true; $__currentLoopData = $reviews; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $review): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
    <div class="review-card">
        <div class="d-flex justify-content-between align-items-center mb-2">
            <strong><?php echo e($review->user->name ?? 'Anonymous'); ?></strong>
            <span class="star-rating">
                <?php echo e(str_repeat('★', (int)$review->rating)); ?><?php echo e(str_repeat('☆', 5 - (int)$review->rating)); ?>

            </span>
        </div>
        <p class="text-muted small mb-2"><?php echo e(\Carbon\Carbon::parse($review->review_date)->format('d M Y')); ?></p>
        <p class="mb-0"><?php echo e($review->review_text); ?></p>
    </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
    <p class="text-muted">No reviews yet. Be the first!</p>
    <?php endif; ?>

</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH E:\3-1 all\db\project\TurnPage\resources\views/books/show.blade.php ENDPATH**/ ?>