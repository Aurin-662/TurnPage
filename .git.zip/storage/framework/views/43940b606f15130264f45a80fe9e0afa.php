

<?php $__env->startSection('title', 'TurnPage — Your Online Bookstore'); ?>

<?php $__env->startSection('styles'); ?>
<style>
    .hero {
        background: linear-gradient(135deg, #1a1a2e 0%, #16213e 60%, #0f3460 100%);
        color: #fff;
        padding: 90px 0 80px;
        text-align: center;
    }
    .hero h1 {
        font-family: 'Merriweather', serif;
        font-size: 2.8rem;
        font-weight: 700;
        margin-bottom: 16px;
    }
    .hero h1 span { color: #e8a045; }
    .hero p { font-size: 1.1rem; color: #b0b8c8; margin-bottom: 32px; }
    .hero .btn-hero {
        background: #e8a045;
        color: #fff;
        border: none;
        padding: 12px 36px;
        font-size: 1rem;
        border-radius: 30px;
        text-decoration: none;
        transition: transform 0.2s, background 0.2s;
    }
    .hero .btn-hero:hover { background: #d4903a; color: #fff; transform: translateY(-2px); }
    .hero-badge {
        display: inline-block;
        background: rgba(255,255,255,0.12);
        border: 1px solid rgba(255,255,255,0.18);
        color: #f4e6bc;
        padding: 8px 14px;
        border-radius: 999px;
        font-size: 0.9rem;
        margin-bottom: 18px;
        backdrop-filter: blur(6px);
    }
    .hero-stats {
        display: flex;
        justify-content: center;
        gap: 16px;
        flex-wrap: wrap;
        margin-top: 28px;
    }
    .hero-stat {
        background: rgba(255,255,255,0.1);
        border: 1px solid rgba(255,255,255,0.16);
        border-radius: 14px;
        padding: 12px 16px;
        min-width: 120px;
    }
    .hero-stat strong { display: block; font-size: 1.1rem; color: #fff; }
    .hero-stat span { font-size: 0.85rem; color: #cfd8e3; }

    .section-title {
        font-family: 'Merriweather', serif;
        font-size: 1.5rem;
        font-weight: 700;
        color: #1a1a2e;
        margin-bottom: 28px;
    }
    .section-title span { color: #e8a045; }

    .book-card {
        background: #fff;
        border: none;
        border-radius: 12px;
        box-shadow: 0 2px 12px rgba(0,0,0,0.07);
        transition: transform 0.2s, box-shadow 0.2s;
        height: 100%;
        overflow: hidden;
        position: relative;
    }
    .book-card:hover { transform: translateY(-4px); box-shadow: 0 8px 24px rgba(0,0,0,0.12); }
    .book-cover {
        height: 200px;
        background: linear-gradient(135deg, #e8e0d5, #d4c9bb);
        border-radius: 12px 12px 0 0;
        display: flex;
        align-items: center;
        justify-content: center;
        font-size: 3rem;
        position: relative;
    }
    .book-badge {
        position: absolute;
        top: 12px;
        left: 12px;
        background: #e8a045;
        color: #fff;
        font-size: 0.72rem;
        padding: 5px 9px;
        border-radius: 999px;
        font-weight: 700;
        text-transform: uppercase;
        letter-spacing: 0.04em;
    }
    .book-stock {
        color: #2e7d32;
        font-size: 0.8rem;
        font-weight: 600;
    }
    .book-title { font-weight: 600; font-size: 0.95rem; margin-bottom: 4px; }
    .book-author { color: #888; font-size: 0.82rem; }
    .book-price { color: #c0392b; font-weight: 700; font-size: 1rem; }
    .star-rating { color: #e8a045; font-size: 0.85rem; }

    .section-subtitle {
        font-size: 0.95rem;
        color: #666;
        margin-bottom: 24px;
    }

    .category-card {
        background: #fff;
        border-radius: 12px;
        padding: 24px;
        text-align: center;
        box-shadow: 0 2px 12px rgba(0,0,0,0.07);
        transition: transform 0.2s, box-shadow 0.2s;
        cursor: pointer;
        height: 100%;
    }
    .category-card:hover { transform: translateY(-4px); box-shadow: 0 8px 24px rgba(0,0,0,0.12); }

    .feature-card {
        background: linear-gradient(145deg, #ffffff, #f8f3ea);
        border: 1px solid #eee2d0;
        border-radius: 14px;
        padding: 22px;
        box-shadow: 0 6px 18px rgba(0,0,0,0.05);
        height: 100%;
    }
    .feature-card h5 { font-weight: 700; color: #1a1a2e; margin-bottom: 8px; }
    .feature-card p { color: #6b7280; margin-bottom: 0; font-size: 0.95rem; }

    .trust-banner {
        background: linear-gradient(135deg, #f8f5ee 0%, #f1e9db 100%);
        border: 1px solid #e9dfcf;
        border-radius: 20px;
        padding: 28px 30px;
        box-shadow: 0 6px 20px rgba(17, 24, 39, 0.04);
    }
    .trust-banner h3 {
        font-family: 'Merriweather', serif;
        color: #1a1a2e;
        margin-bottom: 8px;
        font-size: 1.2rem;
    }
    .trust-banner p {
        color: #6b7280;
        margin-bottom: 0;
    }
    .promo-badge {
        display: inline-block;
        background: #e8a045;
        color: #111827;
        padding: 7px 14px;
        border-radius: 999px;
        font-size: 0.8rem;
        font-weight: 700;
        margin-bottom: 16px;
        text-transform: uppercase;
        letter-spacing: 0.04em;
    }
    .deal-hero {
        display: grid;
        grid-template-columns: 120px minmax(0, 1fr);
        gap: 18px;
        background: linear-gradient(135deg, #111827 0%, #121b2b 100%);
        border-radius: 24px;
        padding: 20px;
        color: #fff;
        box-shadow: 0 14px 32px rgba(17, 24, 39, 0.14);
        align-items: stretch;
    }
    .deal-hero-content {
        min-width: 0;
    }
    .deal-hero-content h3 {
        font-family: 'Merriweather', serif;
        font-size: 1.4rem;
        margin-bottom: 10px;
        line-height: 1.2;
        letter-spacing: -0.02em;
    }
    .deal-hero-content p {
        color: #d1d5e0;
        margin-bottom: 10px;
        font-size: 0.95rem;
        line-height: 1.5;
    }
    .deal-topline {
        display: flex;
        flex-wrap: wrap;
        gap: 10px;
        align-items: center;
        margin-bottom: 10px;
    }
    .deal-topline span {
        display: inline-flex;
        align-items: center;
        gap: 6px;
        color: #cbd5e0;
        font-size: 0.9rem;
    }
    .deal-hero-actions {
        display: flex;
        align-items: center;
        gap: 10px;
        flex-wrap: wrap;
        margin-top: 14px;
    }
    .deal-cover {
        width: 120px;
        height: 176px;
        border-radius: 20px;
        background: #f8f8f8;
        overflow: hidden;
        display: flex;
        align-items: center;
        justify-content: center;
    }
    .deal-cover img {
        width: 100%;
        height: 100%;
        object-fit: cover;
    }
    .deal-cover-placeholder {
        display: flex;
        align-items: center;
        justify-content: center;
        width: 100%;
        height: 100%;
        color: #6b7280;
        font-size: 3rem;
        background: linear-gradient(135deg, #e5e7eb 0%, #d1d5db 100%);
    }
    .deal-price-pill {
        background: #fff;
        color: #111827;
        padding: 7px 12px;
        border-radius: 999px;
        font-weight: 700;
        font-size: 0.9rem;
        white-space: nowrap;
    }
    .deal-pill-row {
        display: flex;
        flex-wrap: wrap;
        gap: 8px;
        margin-top: 10px;
    }
    .deal-pill-row span {
        background: rgba(255,255,255,0.12);
        padding: 5px 9px;
        border-radius: 999px;
        font-size: 0.75rem;
        color: #f5f7fa;
    }
    @media (max-width: 960px) {
        .deal-hero {
            grid-template-columns: 1fr;
            gap: 14px;
            padding: 18px;
        }
        .deal-cover {
            width: 100%;
            height: 180px;
            margin: 0 auto;
        }
        .deal-hero-content h3 {
            font-size: 1.3rem;
        }
        .deal-hero-content p,
        .deal-price-pill,
        .deal-pill-row span {
            font-size: 0.85rem;
        }
        .deal-hero-actions {
            justify-content: flex-start;
        }
    }
    .author-panel {
        height: 100%;
        display: flex;
        flex-direction: column;
        justify-content: flex-start;
        gap: 10px;
    }
    .author-panel .author-list {
        display: grid;
        gap: 10px;
        margin-top: 4px;
    }
    .author-panel .author-item {
        display: flex;
        justify-content: space-between;
        align-items: center;
        padding: 11px 12px;
        background: #fff;
        border-radius: 12px;
        border: 1px solid #f0e4d3;
        box-shadow: 0 3px 10px rgba(0,0,0,0.04);
    }
    .author-panel .author-item:hover {
        transform: translateY(-1px);
        box-shadow: 0 6px 12px rgba(0,0,0,0.06);
    }
    .author-panel .author-name {
        font-weight: 700;
        color: #111827;
    }
    .author-panel .author-meta {
        color: #6b7280;
        font-size: 0.83rem;
    }
    .author-panel .btn-outline-dark {
        border-color: #d1d5db;
        color: #111827;
    }
    .author-panel .btn-outline-dark:hover {
        background: #111827;
        color: #fff;
        border-color: #111827;
    }
    .author-panel-footer {
        margin-top: auto;
        padding-top: 8px;
        border-top: 1px solid #efe4d3;
        display: flex;
        justify-content: space-between;
        align-items: center;
        gap: 10px;
    }
    .author-footer-pill {
        display: inline-flex;
        align-items: center;
        padding: 6px 10px;
        border-radius: 999px;
        background: #f7efe4;
        color: #8a5b19;
        font-size: 0.78rem;
        font-weight: 700;
    }
    .deal-hero .btn-outline-light {
        color: #f8fafc;
        border-color: rgba(248,250,252,0.26);
    }
    .deal-hero .btn-outline-light:hover {
        background: rgba(248,250,252,0.08);
        border-color: rgba(248,250,252,0.38);
    }

    .reveal-on-scroll {
        opacity: 0;
        transform: translateY(18px);
        transition: all 0.6s ease;
    }
    .reveal-on-scroll.is-visible {
        opacity: 1;
        transform: translateY(0);
    }
    .category-icon { font-size: 2.5rem; margin-bottom: 12px; }
    .category-name { font-weight: 600; margin-bottom: 8px; }
    .category-count { font-size: 0.85rem; color: #888; }

    .section-spacing { margin-bottom: 60px; }
</style>
<?php $__env->startSection('scripts'); ?>
<script>
    document.addEventListener('DOMContentLoaded', () => {
        // Use IntersectionObserver when available, otherwise reveal immediately.
        const revealElements = Array.from(document.querySelectorAll('.reveal-on-scroll'));

        if ('IntersectionObserver' in window) {
            const observer = new IntersectionObserver((entries) => {
                entries.forEach(entry => {
                    if (entry.isIntersecting) {
                        entry.target.classList.add('is-visible');
                        observer.unobserve(entry.target);
                    }
                });
            }, { threshold: 0.15 });

            revealElements.forEach(el => observer.observe(el));

            // Safety net: if observer didn't mark elements after a short delay, reveal them.
            setTimeout(() => {
                revealElements.forEach(el => {
                    if (!el.classList.contains('is-visible')) {
                        el.classList.add('is-visible');
                    }
                });
            }, 300);
        } else {
            // Fallback for very old browsers or environments without IntersectionObserver
            revealElements.forEach(el => el.classList.add('is-visible'));
        }
    });
</script>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<!-- Hero -->
<div class="hero">
    <div class="container page-intro">
        <div class="hero-badge">📚 Curated for readers, powered by smart database features</div>
        <h1>Discover Your Next<br><span>Favorite Book</span></h1>
        <p>Thousands of titles, one click away — TurnPage brings the bookstore to you.</p>
        <a href="<?php echo e(route('books.index')); ?>" class="btn-hero">Browse All Books</a>

        <div class="hero-stats">
            <div class="hero-stat">
                <strong>7+</strong>
                <span>Categories</span>
            </div>
            <div class="hero-stat">
                <strong>24/7</strong>
                <span>Easy browsing</span>
            </div>
            <div class="hero-stat">
                <strong>Fast</strong>
                <span>Checkout flow</span>
            </div>
        </div>
    </div>
</div>

<!-- Why TurnPage -->
<div class="container section-spacing mt-5">
    <div class="row g-4 reveal-on-scroll">
        <div class="col-md-4">
            <div class="feature-card">
                <h5>Smart Discovery</h5>
                <p>Explore featured picks, top-rated books, and personalized browsing in one place.</p>
            </div>
        </div>
        <div class="col-md-4">
            <div class="feature-card">
                <h5>Seamless Shopping</h5>
                <p>From book selection to cart and orders, the experience is simple and smooth.</p>
            </div>
        </div>
        <div class="col-md-4">
            <div class="feature-card">
                <h5>Reliable Experience</h5>
                <p>Clean layouts, responsive cards, and polished interactions make the store feel premium.</p>
            </div>
        </div>
    </div>
</div>

<!-- Deal + Authors Section -->
<div class="container section-spacing mt-4">
    <div class="row g-4 reveal-on-scroll align-items-start">
        <div class="col-lg-8">
            <?php if($dealOfTheDay): ?>
            <div class="deal-hero">
                <div class="deal-cover">
                    <?php if(!empty($dealOfTheDay->image)): ?>
                        <img src="<?php echo e(asset($dealOfTheDay->image)); ?>" alt="<?php echo e($dealOfTheDay->title); ?> cover">
                    <?php else: ?>
                        <div class="deal-cover-placeholder">📖</div>
                    <?php endif; ?>
                </div>
                <div class="deal-hero-content">
                    <div class="promo-badge">Deal of the Day</div>
                    <h3><?php echo e($dealOfTheDay->title); ?></h3>
                    <div class="deal-topline">
                        <span>By <?php echo e($dealOfTheDay->author_name ?? 'Popular author'); ?></span>
                        <span class="deal-price-pill">Tk. <?php echo e(number_format($dealOfTheDay->price ?? 0, 0)); ?></span>
                    </div>
                    <p>Rated <?php echo e($dealOfTheDay->star_rating ?? 0); ?>/5</p>
                    <div class="deal-pill-row">
                        <span>⚡ Limited offer</span>
                        <span>📦 In stock</span>
                    </div>
                    <div class="deal-hero-actions">
                        <a href="<?php echo e(route('books.show', $dealOfTheDay->book_id)); ?>" class="btn btn-dark">Grab This Book</a>
                        <a href="<?php echo e(route('books.index')); ?>" class="btn btn-outline-light">Explore More</a>
                    </div>
                </div>
            </div>
            <?php endif; ?>
        </div>

        <div class="col-lg-4 h-100">
            <div class="feature-card author-panel h-100">
                <h5>Popular Authors</h5>
                <p>Explore writers readers love most.</p>
                <div class="author-list mt-3">
                    <?php $__empty_1 = true; $__currentLoopData = $popularAuthors->take(4); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $author): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <div class="author-item">
                        <div>
                            <div class="author-name"><?php echo e($author->author_name); ?></div>
                            <div class="author-meta"><?php echo e($author->total_books); ?> books • <?php echo e($author->country ?? 'Global'); ?></div>
                        </div>
                        <a href="<?php echo e(route('books.index')); ?>?search=<?php echo e(urlencode($author->author_name)); ?>" class="btn btn-sm btn-outline-dark">View</a>
                    </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <p class="text-muted mb-0">No author highlights yet.</p>
                    <?php endif; ?>
                </div>
                <div class="author-panel-footer">
                    <span class="author-footer-pill">Curated picks</span>
                    <a href="<?php echo e(route('books.index')); ?>" class="btn btn-sm btn-outline-dark">Browse all</a>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- New Releases Section -->
<?php if($newArrivals->count() > 0): ?>
<div class="container section-spacing">
    <h2 class="section-title reveal-on-scroll">✨ New <span>Releases</span></h2>
    <p class="section-subtitle">Fresh arrivals and newly added titles</p>

    <div class="row g-4 reveal-on-scroll">
        <?php $__currentLoopData = $newArrivals->take(4); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $book): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="col-md-3">
            <div class="book-card">
                <div class="book-cover overflow-hidden">
                    <?php if($book->has_cover): ?>
                        <img src="<?php echo e($book->cover_url); ?>" alt="<?php echo e($book->title); ?>" class="img-fluid h-100 w-100" style="object-fit: cover; position: absolute; inset: 0;" onerror="this.onerror=null;this.style.display='none'">
                    <?php else: ?>
                        <div class="d-flex align-items-center justify-content-center h-100 w-100" style="font-size: 3rem; color: #6b7280; background: linear-gradient(135deg, #e5e7eb 0%, #d1d5db 100%);">
                            📖
                        </div>
                    <?php endif; ?>
                    <span class="book-badge">New</span>
                </div>
                <div class="p-3">
                    <p class="book-title"><?php echo e($book->title); ?></p>
                    <p class="book-author mb-1"><?php echo e($book->author_name ?? 'Unknown'); ?></p>
                    <p class="book-stock mb-2">In Stock</p>
                    <div class="d-flex justify-content-between align-items-center mt-2">
                        <span class="book-price">Tk. <?php echo e(number_format($book->price, 0)); ?></span>
                        <a href="<?php echo e(route('books.show', $book->book_id)); ?>" class="btn btn-sm btn-outline-dark">View</a>
                    </div>
                </div>
            </div>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
</div>
<?php endif; ?>

<!-- Featured Books Section -->
<div class="container mt-5 section-spacing">
    <h2 class="section-title reveal-on-scroll">⭐ Featured <span>Books</span></h2>
    <p class="section-subtitle">Handpicked bestsellers and highest-rated books</p>

    <div class="row g-4 reveal-on-scroll">
        <?php $__empty_1 = true; $__currentLoopData = $featuredBooks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $book): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
        <div class="col-md-3">
            <div class="book-card">
                <div class="book-cover overflow-hidden" style="position: relative;">
                    <div class="d-flex align-items-center justify-content-center h-100 w-100" style="font-size: 3rem; color: #6b7280; background: linear-gradient(135deg, #e5e7eb 0%, #d1d5db 100%); position: absolute; inset: 0;">
                        📖
                    </div>
                    <?php if($book->has_cover): ?>
                        <img src="<?php echo e($book->cover_url); ?>" alt="<?php echo e($book->title); ?>" class="img-fluid h-100 w-100" style="object-fit: cover; position: absolute; inset: 0;" onerror="this.onerror=null;this.style.display='none'">
                    <?php endif; ?>
                    <span class="book-badge">Featured</span>
                </div>
                <div class="p-3">
                    <p class="book-title"><?php echo e($book->title); ?></p>
                    <p class="book-author mb-1"><?php echo e($book->author_name ?? 'Unknown'); ?></p>
                    <p class="star-rating mb-1">★ <?php echo e($book->star_rating ?? 0); ?>

                        <small class="text-muted">(<?php echo e($book->review_count ?? 0); ?>)</small>
                    </p>
                    <div class="d-flex justify-content-between align-items-center mt-2">
                        <span class="book-price">Tk. <?php echo e(number_format($book->price, 0)); ?></span>
                        <a href="<?php echo e(route('books.show', $book->book_id)); ?>" class="btn btn-sm btn-outline-dark">View</a>
                    </div>
                </div>
            </div>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
        <div class="col-12 text-center py-4">
            <p class="text-muted">No featured books available yet.</p>
        </div>
        <?php endif; ?>
    </div>
</div>

<!-- Categories Section -->
<div class="container section-spacing">
    <h2 class="section-title reveal-on-scroll">📚 Browse by <span>Category</span></h2>
    <p class="section-subtitle">Explore books organized by category</p>

    <div class="row g-4 reveal-on-scroll">
        <?php $__empty_1 = true; $__currentLoopData = $categorySummary; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
        <div class="col-md-3">
            <a href="<?php echo e(route('categories.show', $cat->category_id)); ?>" class="text-decoration-none">
                <div class="category-card">
                    <div class="category-icon"><?php echo e($cat->icon); ?></div>
                    <h5 class="category-name"><?php echo e($cat->category_name); ?></h5>
                    <p class="category-count"><?php echo e($cat->total_books); ?> books</p>
                </div>
            </a>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
        <div class="col-12 text-center">
            <p class="text-muted">No categories available.</p>
        </div>
        <?php endif; ?>
    </div>
</div>

<!-- Best Sellers Section -->
<?php if($bestSellers->count() > 0): ?>
<div class="container section-spacing">
    <h2 class="section-title reveal-on-scroll">🔥 Best <span>Sellers</span></h2>
    <p class="section-subtitle">Most popular books this month</p>

    <div class="row g-4 reveal-on-scroll">
        <?php $__currentLoopData = $bestSellers->take(8); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $book): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="col-md-3">
            <div class="book-card">
                <div class="book-cover overflow-hidden" style="position: relative;">
                    <div class="d-flex align-items-center justify-content-center h-100 w-100" style="font-size: 3rem; color: #6b7280; background: linear-gradient(135deg, #e5e7eb 0%, #d1d5db 100%); position: absolute; inset: 0;">
                        📖
                    </div>
                    <?php if($book->has_cover): ?>
                        <img src="<?php echo e($book->cover_url); ?>" alt="<?php echo e($book->title); ?>" class="img-fluid h-100 w-100" style="object-fit: cover; position: absolute; inset: 0;" onerror="this.onerror=null;this.style.display='none'">
                    <?php endif; ?>
                    <span class="book-badge">Bestseller</span>
                </div>
                <div class="p-3">
                    <p class="book-title"><?php echo e($book->title); ?></p>
                    <p class="book-author mb-1"><?php echo e($book->author_name ?? 'Unknown'); ?></p>
                    <p class="star-rating mb-1">★ <?php echo e($book->star_rating ?? 0); ?></p>
                    <div class="d-flex justify-content-between align-items-center mt-2">
                        <span class="book-price">Tk. <?php echo e(number_format($book->price, 0)); ?></span>
                        <a href="<?php echo e(route('books.show', $book->book_id)); ?>" class="btn btn-sm btn-outline-dark">View</a>
                    </div>
                </div>
            </div>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
</div>
<?php endif; ?>

<!-- New Arrivals Section -->
<?php if($newArrivals->count() > 0): ?>
<div class="container section-spacing">
    <h2 class="section-title reveal-on-scroll">✨ New <span>Arrivals</span></h2>
    <p class="section-subtitle">Recently added to our collection</p>

    <div class="row g-4 reveal-on-scroll">
        <?php $__currentLoopData = $newArrivals->take(8); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $book): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="col-md-3">
            <div class="book-card">
                <div class="book-cover overflow-hidden" style="position: relative;">
                    <div class="d-flex align-items-center justify-content-center h-100 w-100" style="font-size: 3rem; color: #6b7280; background: linear-gradient(135deg, #e5e7eb 0%, #d1d5db 100%); position: absolute; inset: 0;">
                        📖
                    </div>
                    <?php if($book->has_cover): ?>
                        <img src="<?php echo e($book->cover_url); ?>" alt="<?php echo e($book->title); ?>" class="img-fluid h-100 w-100" style="object-fit: cover; position: absolute; inset: 0;" onerror="this.onerror=null;this.style.display='none'">
                    <?php endif; ?>
                    <span class="book-badge">Popular</span>
                </div>
                <div class="p-3">
                    <p class="book-title"><?php echo e($book->title); ?></p>
                    <p class="book-author mb-1"><?php echo e($book->author_name ?? 'Unknown'); ?></p>
                    <p class="star-rating mb-1">★ <?php echo e($book->star_rating ?? 0); ?></p>
                    <div class="d-flex justify-content-between align-items-center mt-2">
                        <span class="book-price">Tk. <?php echo e(number_format($book->price, 0)); ?></span>
                        <a href="<?php echo e(route('books.show', $book->book_id)); ?>" class="btn btn-sm btn-outline-dark">View</a>
                    </div>
                </div>
            </div>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
</div>
<?php endif; ?>

<!-- Trust / CTA Section -->
<div class="container section-spacing">
    <div class="trust-banner reveal-on-scroll">
        <div class="row align-items-center g-4">
            <div class="col-lg-8">
                <div class="promo-badge">Trusted by readers</div>
                <h3>Build your personal library with books you’ll actually love</h3>
                <p>From bestsellers to hidden gems, TurnPage helps you discover, compare, and buy books in a smooth experience.</p>
            </div>
            <div class="col-lg-4 text-lg-end">
                <a href="<?php echo e(route('books.index')); ?>" class="btn btn-dark">Explore Books</a>
            </div>
        </div>
    </div>
</div>

<!-- Top Rated Books Section -->
<?php if($topRatedBooks->count() > 0): ?>
<div class="container section-spacing">
    <h2 class="section-title reveal-on-scroll">👑 Top <span>Rated</span></h2>
    <p class="section-subtitle">Highest-rated books by customers (minimum 3 reviews)</p>

    <div class="row g-4 reveal-on-scroll">
        <?php $__currentLoopData = $topRatedBooks->take(6); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $book): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="col-md-4">
            <div class="book-card">
                <div class="book-cover">
                    <span class="book-badge">Top Rated</span>
                    📖
                </div>
                <div class="p-3">
                    <p class="book-title"><?php echo e($book->title); ?></p>
                    <p class="book-author mb-1"><?php echo e($book->author_name ?? 'Unknown'); ?></p>
                    <p class="star-rating mb-1">★ <?php echo e($book->star_rating ?? 0); ?>

                        <small class="text-muted">(<?php echo e($book->review_count ?? 0); ?>)</small>
                    </p>
                    <div class="d-flex justify-content-between align-items-center mt-2">
                        <span class="book-price">Tk. <?php echo e(number_format($book->price, 0)); ?></span>
                        <a href="<?php echo e(route('books.show', $book->book_id)); ?>" class="btn btn-sm btn-outline-dark">View</a>
                    </div>
                </div>
            </div>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
</div>
<?php endif; ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH E:\3-1 all\db\project\TurnPage\resources\views/home.blade.php ENDPATH**/ ?>