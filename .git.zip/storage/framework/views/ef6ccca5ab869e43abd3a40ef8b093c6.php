

<?php $__env->startSection('title', 'Manage Books — Admin'); ?>

<?php $__env->startSection('styles'); ?>
<style>
    .table-card { background: #fff; border-radius: 10px; padding: 25px; box-shadow: 0 2px 10px rgba(0,0,0,0.08); }
    .stock-low { background: #f8d7da; color: #721c24; padding: 2px 8px; border-radius: 10px; font-size: 0.8rem; font-weight: 600; }
</style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="container mt-4 pb-5">
    <div class="d-flex flex-column flex-md-row justify-content-between align-items-start align-items-md-center mb-4 gap-3">
        <div>
            <h2 style="font-family:'Inter',sans-serif; font-weight:700;">Manage Books</h2>
            <p class="text-muted mb-0">Search by book title, ISBN, author, or publisher.</p>
        </div>
        <div class="d-flex gap-2 w-100 w-md-auto">
            <form action="<?php echo e(route('admin.books.index')); ?>" method="GET" class="d-flex gap-2 w-100">
                <input type="search" name="search" class="form-control form-control-sm" placeholder="Search books..." value="<?php echo e($search ?? request('search')); ?>">
                <button type="submit" class="btn btn-dark btn-sm">Search</button>
            </form>
            <a href="<?php echo e(route('admin.books.index')); ?>" class="btn btn-outline-secondary btn-sm">Reset</a>
        </div>
        <a href="<?php echo e(route('admin.books.create')); ?>" class="btn btn-dark">+ Add New Book</a>
    </div>

    <div class="table-card">
        <table class="table table-hover align-middle">
            <thead class="table-dark">
                <tr>
                    <th>ID</th>
                    <th>Title</th>
                    <th>Author</th>
                    <th>Price</th>
                    <th>Stock</th>
                    <th>Rating</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $books; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $book): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td class="text-muted small"><?php echo e($book->book_id); ?></td>
                    <td><strong><?php echo e($book->title); ?></strong></td>
                    <td><?php echo e($book->author->author_name ?? 'N/A'); ?></td>
                    <td>Tk. <?php echo e(number_format($book->price, 0)); ?></td>
                    <td>
                        <?php if($book->stock_quantity <= 5): ?>
                            <span class="stock-low"><?php echo e($book->stock_quantity); ?> low</span>
                        <?php else: ?>
                            <?php echo e($book->stock_quantity); ?>

                        <?php endif; ?>
                    </td>
                    <td>⭐ <?php echo e($book->star_rating); ?></td>
                    <td>
                        <a href="<?php echo e(route('admin.books.edit', $book->book_id)); ?>" class="btn btn-sm btn-outline-primary me-1">Edit</a>
                        <form action="<?php echo e(route('admin.books.destroy', $book->book_id)); ?>" method="POST" class="d-inline" onsubmit="return confirm('Delete this book?');">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('DELETE'); ?>
                            <button type="submit" class="btn btn-sm btn-outline-danger">Delete</button>
                        </form>
                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH E:\3-1 all\db\project\TurnPage\resources\views/admin/books/index.blade.php ENDPATH**/ ?>