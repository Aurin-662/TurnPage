

<?php $__env->startSection('title', 'My Orders — TurnPage'); ?>

<?php $__env->startSection('styles'); ?>
<style>
    .order-card { background: #fff; border-radius: 10px; padding: 24px; margin-bottom: 20px; box-shadow: 0 2px 8px rgba(0,0,0,0.06); }
    .status-badge { padding: 4px 12px; border-radius: 20px; font-size: 0.8rem; font-weight: 600; }
    .status-Pending { background: #fff3cd; color: #856404; }
    .status-Processing { background: #cfe2ff; color: #084298; }
    .status-Shipped { background: #e2d9f3; color: #432874; }
    .status-Delivered { background: #d1e7dd; color: #0a3622; }
    .status-Cancelled { background: #f8d7da; color: #58151c; }
    .price-tag { color: #c0392b; font-weight: 700; }
</style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="container mt-4 pb-5">
    <h2 class="mb-4" style="font-family:'Merriweather',serif;">My Orders</h2>

    <?php $__empty_1 = true; $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
    <div class="order-card">
        <div class="d-flex justify-content-between align-items-center mb-3">
            <div>
                <h6 class="mb-0">Order #<?php echo e($order->order_id); ?></h6>
                <small class="text-muted"><?php echo e(\Carbon\Carbon::parse($order->order_date)->format('d M Y')); ?></small>
            </div>
            <span class="status-badge status-<?php echo e($order->status); ?>"><?php echo e($order->status); ?></span>
        </div>
        <hr>
        <?php $__currentLoopData = $order->items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="d-flex justify-content-between mb-1">
            <span><?php echo e($item->book->title ?? 'Book'); ?> <span class="text-muted">× <?php echo e($item->quantity); ?></span></span>
            <span>Tk. <?php echo e(number_format($item->price * $item->quantity, 2)); ?></span>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <hr>
        <div class="d-flex justify-content-between align-items-center">
            <small class="text-muted"><?php echo e($order->payment->payment_method ?? 'N/A'); ?> · <?php echo e($order->payment->payment_status ?? 'N/A'); ?></small>
            <span class="price-tag">Tk. <?php echo e(number_format($order->total_amount, 2)); ?></span>
        </div>
    </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
    <div class="text-center py-5">
        <div style="font-size:5rem;">📦</div>
        <h4 class="mt-3 text-muted">No orders yet</h4>
        <a href="<?php echo e(route('books.index')); ?>" class="btn btn-dark mt-3">Start Shopping</a>
    </div>
    <?php endif; ?>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH E:\3-1 all\db\project\TurnPage\resources\views/checkout/history.blade.php ENDPATH**/ ?>