

<?php $__env->startSection('title', 'Manage Orders — Admin'); ?>

<?php $__env->startSection('styles'); ?>
<style>
    .order-card { background: #fff; border-radius: 10px; padding: 20px; margin-bottom: 16px; box-shadow: 0 2px 8px rgba(0,0,0,0.06); }
    .status-Pending { background: #fff3cd; color: #856404; }
    .status-Processing { background: #cfe2ff; color: #084298; }
    .status-Shipped { background: #e2d9f3; color: #432874; }
    .status-Delivered { background: #d1e7dd; color: #0a3622; }
    .status-Cancelled { background: #f8d7da; color: #58151c; }
    .status-badge { padding: 4px 12px; border-radius: 20px; font-size: 0.8rem; font-weight: 600; }
</style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="container mt-4 pb-5">
    <h2 class="mb-4" style="font-weight:700;">Manage Orders</h2>

    <?php $__empty_1 = true; $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
    <div class="order-card">
        <div class="d-flex justify-content-between align-items-center mb-2">
            <div>
                <strong>Order #<?php echo e($order->order_id); ?></strong>
                <span class="text-muted small ms-2">— <?php echo e($order->user->name ?? 'Unknown'); ?></span>
                <span class="text-muted small ms-2"><?php echo e(\Carbon\Carbon::parse($order->order_date)->format('d M Y, h:i A')); ?></span>
            </div>
            <span class="status-badge status-<?php echo e($order->status); ?>"><?php echo e($order->status); ?></span>
        </div>
        <hr class="my-2">
        <?php $__currentLoopData = $order->items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="d-flex justify-content-between small">
            <span><?php echo e($item->book->title ?? 'Book'); ?> × <?php echo e($item->quantity); ?></span>
            <span>Tk. <?php echo e(number_format($item->price * $item->quantity, 0)); ?></span>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <hr class="my-2">
        <div class="d-flex justify-content-between align-items-center">
            <div>
                <span class="fw-bold">Tk. <?php echo e(number_format($order->total_amount, 0)); ?></span>
                <span class="text-muted small ms-2">· <?php echo e($order->payment->payment_method ?? 'N/A'); ?></span>
            </div>
            <form action="<?php echo e(route('admin.orders.updateStatus', $order->order_id)); ?>" method="POST" class="d-flex gap-2">
                <?php echo csrf_field(); ?>
                <?php echo method_field('PUT'); ?>
                <select name="status" class="form-select form-select-sm" style="width:160px;">
                    <?php $__currentLoopData = ['Pending','Processing','Shipped','Delivered','Cancelled']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $status): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($status); ?>" <?php echo e($order->status == $status ? 'selected' : ''); ?>><?php echo e($status); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
                <button type="submit" class="btn btn-sm btn-dark">Update</button>
            </form>
        </div>
    </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
    <p class="text-muted">No orders yet.</p>
    <?php endif; ?>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH E:\3-1 all\db\project\TurnPage\resources\views/admin/orders/index.blade.php ENDPATH**/ ?>