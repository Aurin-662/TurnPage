

<?php $__env->startSection('title', 'Manage Vouchers — Admin'); ?>

<?php $__env->startSection('styles'); ?>
<style>
    .table-card { background: #fff; border-radius: 10px; padding: 25px; box-shadow: 0 2px 10px rgba(0,0,0,0.08); }
</style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="container mt-4 pb-5">
    <div class="d-flex justify-content-between align-items-center mb-4">
        <h2 style="font-weight:700;">Manage Vouchers</h2>
        <a href="<?php echo e(route('admin.vouchers.create')); ?>" class="btn btn-dark">+ Create Voucher</a>
    </div>

    <div class="table-card">
        <table class="table table-hover align-middle">
            <thead class="table-dark">
                <tr>
                    <th>Code</th>
                    <th>Discount</th>
                    <th>Min. Amount</th>
                    <th>Valid From</th>
                    <th>Valid To</th>
                    <th>Usage Limit</th>
                    <th>Status</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $vouchers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $v): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><strong><?php echo e($v->voucher_code); ?></strong></td>
                    <td><?php echo e($v->discount_percent); ?>%</td>
                    <td>Tk. <?php echo e(number_format($v->minimum_amount, 0)); ?></td>
                    <td><?php echo e($v->valid_from ? \Carbon\Carbon::parse($v->valid_from)->format('d M Y') : '-'); ?></td>
                    <td><?php echo e($v->valid_to ? \Carbon\Carbon::parse($v->valid_to)->format('d M Y') : '-'); ?></td>
                    <td><?php echo e($v->usage_limit); ?></td>
                    <td>
                        <?php if($v->is_active): ?>
                            <span class="badge bg-success">Active</span>
                        <?php else: ?>
                            <span class="badge bg-secondary">Inactive</span>
                        <?php endif; ?>
                    </td>
                    <td>
                        <form action="<?php echo e(route('admin.vouchers.toggle', $v->voucher_id)); ?>" method="POST" class="d-inline">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('PUT'); ?>
                            <button type="submit" class="btn btn-sm <?php echo e($v->is_active ? 'btn-outline-warning' : 'btn-outline-success'); ?>">
                                <?php echo e($v->is_active ? 'Deactivate' : 'Activate'); ?>

                            </button>
                        </form>
                        <form action="<?php echo e(route('admin.vouchers.destroy', $v->voucher_id)); ?>" method="POST" class="d-inline" onsubmit="return confirm('Delete?');">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('DELETE'); ?>
                            <button type="submit" class="btn btn-sm btn-outline-danger">Delete</button>
                        </form>
                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH E:\3-1 all\db\project\TurnPage\resources\views/admin/vouchers/index.blade.php ENDPATH**/ ?>