

<?php $__env->startSection('title', 'My Cart — TurnPage'); ?>

<?php $__env->startSection('styles'); ?>
<style>
    .cart-card { background: #fff; border-radius: 10px; padding: 20px; box-shadow: 0 2px 8px rgba(0,0,0,0.06); margin-bottom: 16px; }
    .cart-book-cover { width: 70px; height: 90px; background: linear-gradient(135deg, #e8e0d5, #d4c9bb); border-radius: 6px; display: flex; align-items: center; justify-content: center; font-size: 1.8rem; flex-shrink: 0; }
    .summary-box { background: #fff; border-radius: 10px; padding: 24px; box-shadow: 0 2px 8px rgba(0,0,0,0.06); position: sticky; top: 90px; }
    .btn-checkout { background: #c0392b; color: #fff; border: none; padding: 14px; border-radius: 8px; font-size: 1rem; width: 100%; }
    .btn-checkout:hover { background: #a93226; color: #fff; }
    .price-tag { color: #c0392b; font-weight: 700; }
</style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="container mt-4 pb-5">
    <h2 class="mb-4" style="font-family:'Merriweather',serif;">My Cart</h2>

    <?php if(count($cartItems) > 0): ?>
    <div class="row g-4">
        <div class="col-md-8">
            <?php $__currentLoopData = $cartItems; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="cart-card reveal-on-scroll d-flex gap-3 align-items-center">
                <div class="cart-book-cover">📖</div>
                <div class="flex-grow-1">
                    <h6 class="mb-1"><?php echo e($item->book->title ?? 'Unknown'); ?></h6>
                    <p class="text-muted small mb-2">Tk. <?php echo e(number_format($item->price, 2)); ?> each</p>
                    <form action="<?php echo e(route('cart.update', $item->cart_item_id)); ?>" method="POST" class="d-flex align-items-center gap-2">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('PUT'); ?>
                        <input type="number" name="quantity" value="<?php echo e($item->quantity); ?>" min="1" class="form-control form-control-sm" style="width:70px;">
                        <button type="submit" class="btn btn-sm btn-outline-secondary">Update</button>
                    </form>
                </div>
                <div class="text-end">
                    <p class="price-tag mb-2">Tk. <?php echo e(number_format($item->price * $item->quantity, 2)); ?></p>
                    <form action="<?php echo e(route('cart.remove', $item->cart_item_id)); ?>" method="POST">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('DELETE'); ?>
                        <button type="submit" class="btn btn-sm btn-link text-danger p-0">Remove</button>
                    </form>
                </div>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>

        <div class="col-md-4">
            <div class="summary-box reveal-on-scroll">
                <h6 class="mb-3">Order Summary</h6>
                <hr>
                <div class="d-flex justify-content-between mb-2">
                    <span class="text-muted">Subtotal (<?php echo e(count($cartItems)); ?> items)</span>
                    <span>Tk. <?php echo e(number_format($cartItems->sum(fn($i) => $i->price * $i->quantity), 2)); ?></span>
                </div>
                <hr>
                <div class="d-flex justify-content-between fw-bold mb-4">
                    <span>Total</span>
                    <span class="price-tag">Tk. <?php echo e(number_format($cartItems->sum(fn($i) => $i->price * $i->quantity), 2)); ?></span>
                </div>
                <a href="<?php echo e(route('checkout.show')); ?>" class="btn-checkout text-decoration-none d-block text-center">Proceed to Checkout →</a>
            </div>
        </div>
    </div>
    <?php else: ?>
    <div class="text-center py-5">
        <div style="font-size:5rem;">🛒</div>
        <h4 class="mt-3 text-muted">Your cart is empty</h4>
        <a href="<?php echo e(route('books.index')); ?>" class="btn btn-dark mt-3">Browse Books</a>
    </div>
    <?php endif; ?>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH E:\3-1 all\db\project\TurnPage\resources\views/cart/index.blade.php ENDPATH**/ ?>