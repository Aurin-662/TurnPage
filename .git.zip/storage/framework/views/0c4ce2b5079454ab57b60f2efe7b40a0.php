

<?php $__env->startSection('title', 'Dashboard — Admin'); ?>

<?php $__env->startSection('styles'); ?>
<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
<style>
    .stat-card { background: #fff; border-radius: 12px; padding: 24px; box-shadow: 0 2px 10px rgba(0,0,0,0.08); }
    .stat-number { font-size: 2rem; font-weight: 700; }
    .stat-label { color: #888; font-size: 0.78rem; text-transform: uppercase; letter-spacing: 1px; }
    .chart-card { background: #fff; border-radius: 12px; padding: 24px; box-shadow: 0 2px 10px rgba(0,0,0,0.08); }
    .table-card { background: #fff; border-radius: 12px; padding: 24px; box-shadow: 0 2px 10px rgba(0,0,0,0.08); }
    .status-Pending { background:#fff3cd; color:#856404; }
    .status-Processing { background:#cfe2ff; color:#084298; }
    .status-Shipped { background:#e2d9f3; color:#432874; }
    .status-Delivered { background:#d1e7dd; color:#0a3622; }
    .status-Cancelled { background:#f8d7da; color:#58151c; }
    .status-badge { padding: 3px 10px; border-radius: 20px; font-size: 0.75rem; font-weight: 600; }
</style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="container mt-4 pb-5">
    <h2 class="mb-4" style="font-weight:700;">Dashboard</h2>

    <!-- Stats Row -->
    <div class="row g-4 mb-4">
        <div class="col-md-3">
            <div class="stat-card border-start border-success border-4">
                <div class="stat-label">Total Revenue</div>
                <div class="stat-number text-success">Tk. <?php echo e(number_format($totalRevenue, 0)); ?></div>
            </div>
        </div>
        <div class="col-md-3">
            <div class="stat-card border-start border-primary border-4">
                <div class="stat-label">Total Orders</div>
                <div class="stat-number text-primary"><?php echo e($totalOrders); ?></div>
            </div>
        </div>
        <div class="col-md-3">
            <div class="stat-card border-start border-warning border-4">
                <div class="stat-label">Total Customers</div>
                <div class="stat-number text-warning"><?php echo e($totalCustomers); ?></div>
            </div>
        </div>
        <div class="col-md-3">
            <div class="stat-card border-start border-danger border-4">
                <div class="stat-label">Total Books</div>
                <div class="stat-number text-danger"><?php echo e($totalBooks); ?></div>
            </div>
        </div>
    </div>

    <!-- Charts Row -->
    <div class="row g-4 mb-4">
        <div class="col-md-6">
            <div class="chart-card">
                <h6 class="mb-3 fw-semibold">Orders by Status</h6>
                <canvas id="statusChart" height="200"></canvas>
            </div>
        </div>
        <div class="col-md-6">
            <div class="chart-card">
                <h6 class="mb-3 fw-semibold">Revenue by Payment Method</h6>
                <canvas id="paymentChart" height="200"></canvas>
            </div>
        </div>
    </div>

    <!-- Top Books + Recent Orders -->
    <div class="row g-4">
        <div class="col-md-6">
            <div class="table-card">
                <h6 class="mb-3 fw-semibold">🏆 Top 5 Bestselling Books</h6>
                <table class="table table-sm table-hover">
                    <thead class="table-light">
                        <tr>
                            <th>#</th>
                            <th>Title</th>
                            <th>Sold</th>
                            <th>Revenue</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $topBooks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i => $book): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td class="text-muted"><?php echo e($i + 1); ?></td>
                            <td><?php echo e(Str::limit($book->title, 25)); ?></td>
                            <td><span class="badge bg-dark"><?php echo e($book->total_sold); ?></span></td>
                            <td>Tk. <?php echo e(number_format($book->total_revenue, 0)); ?></td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>

        <div class="col-md-6">
            <div class="table-card">
                <h6 class="mb-3 fw-semibold">🕐 Recent Orders</h6>
                <table class="table table-sm table-hover">
                    <thead class="table-light">
                        <tr>
                            <th>Order</th>
                            <th>Customer</th>
                            <th>Total</th>
                            <th>Status</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $recentOrders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td>#<?php echo e($order->order_id); ?></td>
                            <td><?php echo e($order->customer_name); ?></td>
                            <td>Tk. <?php echo e(number_format($order->total_amount, 0)); ?></td>
                            <td><span class="status-badge status-<?php echo e($order->status); ?>"><?php echo e($order->status); ?></span></td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
<script>
const statusCtx = document.getElementById('statusChart').getContext('2d');
new Chart(statusCtx, {
    type: 'doughnut',
    data: {
        labels: [<?php $__currentLoopData = $ordersByStatus; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $s): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> '<?php echo e($s->status); ?>', <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>],
        datasets: [{
            data: [<?php $__currentLoopData = $ordersByStatus; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $s): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> <?php echo e($s->total); ?>, <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>],
            backgroundColor: ['#f39c12','#3498db','#9b59b6','#27ae60','#e74c3c'],
            borderWidth: 0,
        }]
    },
    options: {
        plugins: { legend: { position: 'bottom' } },
        cutout: '65%'
    }
});

const paymentCtx = document.getElementById('paymentChart').getContext('2d');
new Chart(paymentCtx, {
    type: 'bar',
    data: {
        labels: [<?php $__currentLoopData = $revenueByMethod; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $r): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> '<?php echo e($r->payment_method); ?>', <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>],
        datasets: [{
            label: 'Revenue (Tk.)',
            data: [<?php $__currentLoopData = $revenueByMethod; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $r): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> <?php echo e($r->total); ?>, <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>],
            backgroundColor: ['#1a1a2e','#c0392b','#27ae60'],
            borderRadius: 6,
        }]
    },
    options: {
        plugins: { legend: { display: false } },
        scales: { y: { beginAtZero: true, grid: { color: '#f0f0f0' } }, x: { grid: { display: false } } }
    }
});
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH E:\3-1 all\db\project\TurnPage\resources\views/admin/dashboard.blade.php ENDPATH**/ ?>